-- ##########################################################################
-- please make sure to hit the subscribe button to my youtube MononokeStudios
-- please make sure you go visit https://www.Mononoke-Studios.dev
-- please make sure to take a look at my other scripts on https://www.m-scripts.store
-- join our discord server https://discord.gg/Kd8h2YmvHV
-- ##########################################################################
-- thanks for using my scripts best regards and god bless you
-- by Deilmos
-- Mononoke-Studios
-- ##########################################################################

## Installation

1. Copy the resource folder into your server resources directory:

2. Ensure the resource in your `server.cfg`:

3. Open `config.lua` and configure the toggles to your needs.

4. Restart the server (or start the resource). // You could use TX Admin to easy test

That’s it.

---

# Simple Weather Lock

Standalone client-side weather script for FiveM (works with ESX & QBCore).


## Config
Edit `config.lua`:

- `Config.Weather = "XMAS"`
- `Config.FreezeWeather = true`

Allowed values:
CLEAR, EXTRASUNNY, CLOUDS, OVERCAST, RAIN, CLEARING,
THUNDER, SMOG, FOGGY, XMAS, SNOW, SNOWLIGHT,
HALLOWEEN, NEUTRAL, RAIN_HALLOWEEN, SNOW_HALLOWEEN


Compatibility

ESX ✔

QBCore ✔

Standalone ✔

No server-side dependencies

No database required

License / Usage

You may:

Use this resource on your server

Modify it for your needs

You may not:

Re-upload as-is without permission

Claim original authorship while its made by me deilmos


-- ##########################################################################
-- please make sure to hit the subscribe button to my youtube MononokeStudios
-- please make sure you go visit https://www.Mononoke-Studios.dev
-- please make sure to take a look at my other scripts on https://www.m-scripts.store
-- join our discord server https://discord.gg/Kd8h2YmvHV
-- ##########################################################################
-- thanks for using my scripts best regards and god bless you
-- by Deilmos
-- Mononoke-Studios
-- ##########################################################################

