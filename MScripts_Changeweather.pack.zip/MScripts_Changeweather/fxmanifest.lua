fx_version 'cerulean'
game 'gta5'

author 'Deilmos'

-- God bless you --

description 'MScripts Changeweather '
version '1.0.0'

-- Client-only script
client_scripts {
    'client.lua'
}

shared_scripts {
     'config.lua' 
}

-- ##########################################################################
-- please make sure to hit the subscribe button to my youtube MononokeStudios
-- please make sure you go visit https://www.Mononoke-Studios.dev
-- please make sure to take a look at my other scripts on https://www.m-scripts.store
-- join our discord server https://discord.gg/Kd8h2YmvHV
-- Check our Youtube Channel MononokeStudios
-- Check our Homepage https://www.Mononoke-Studios.dev
-- ##########################################################################
-- thanks for using my scripts best regards and god bless you
-- by Deilmos
-- Mononoke-Studios
-- ##########################################################################
dependency '/assetpacks'